package com.practice.algorithms;

public class CountUsingThumb {
	public static void main(String[] args) {
		
		int input = 11;
		/*
		 * int[] arr = new int[5]; int k = 1; int j = 1; int val = k; boolean flag =
		 * false;
		 *//*
		 * while(k!=input) {
		 * 
		 * if(j==1) {
		 * 
		 * flag =true ; j++; k++; }else if(j==5){ flag = false; j--; k++; } }
		 */
		
		
		
		/*
		 * int thumb = 0; int index = 1; int middle = 2; int ring = 4; int small = 5;
		 */

		int result = 0;
		int vl = input%5;
		String ans = null;
		if(vl == 0) {
			 result = vl-1;
		}else {
			result = 5-(vl+(input/5)-2);
		}
		switch(result) {
		case 0:
			ans = "thumb";
			break;
		case 1:
			ans = "index";
			break;
		case 2:
			ans = "middle";	
			break;
		case 3:
			ans = "ring";
			break;
		case 4:
			ans = "small";
			break;
		}
		System.out.println(ans);
		
	}
}
