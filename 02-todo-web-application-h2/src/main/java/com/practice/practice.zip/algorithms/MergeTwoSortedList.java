/*
 * package com.practice.algorithms;
 * 
 * public class MergeTwoSortedList {
 * 
 * public static ListNode mergeTwoLists(ListNode l1, ListNode l2) {
 * 
 * public static void main(String[] args) {
 * 
 * mergeTwoLists(); }
 * 
 * }
 */