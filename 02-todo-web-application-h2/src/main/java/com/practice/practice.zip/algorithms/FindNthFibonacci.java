package com.practice.algorithms;

import java.util.Scanner;

public class FindNthFibonacci {
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		        long n = sc.nextInt();
		        long s1 = 0;long s2 =1;
		        if(n!=0) {
		        for(long i=2;i<=n;i++){
		            long s3 = s1+s2;
		            if(i==n){
		                System.out.println(s3);
		            }else{
		            s1=s2;
		            s2=s3;
		            }
		        }
		        }
		    }
		

}
