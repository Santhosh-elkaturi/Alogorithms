# spring-boot-docker-maven-example
How to dockerize  spring boot application using maven plugin 

## Maven plugin
![plugin](https://user-images.githubusercontent.com/25712816/52089025-874fec80-25d3-11e9-9bca-61f10c87002d.PNG)

### Docker Hub 
![docker-hub](https://user-images.githubusercontent.com/25712816/52089001-73a48600-25d3-11e9-998c-1fffb15e6571.PNG)
